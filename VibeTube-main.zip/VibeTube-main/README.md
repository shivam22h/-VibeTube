# VibeTube
- Made using React and Tailwind CSS
- Works for both PC and Mobile
- API key from ApiHub: https://rapidapi.com/Glavier/api/youtube138/playground/apiendpoint_ec94e76b-0c7b-4de5-8674-8ec696f369a5
- Tailwind CSS package installations: https://tailwindcss.com/docs/installation
- Node.js: https://nodejs.org/en
- To run npm start
- hosted on: https://rainbow-cannoli-f06e66.netlify.app/
